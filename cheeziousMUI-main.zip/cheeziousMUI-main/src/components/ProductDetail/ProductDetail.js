import { Box } from "@mui/system";
import React from "react";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import { Button } from "@mui/material";
import product from "../../images/product-detail.jpeg";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import { ProductDetailStyles } from "../../Theme";
import { useAddToCart } from "../Hooks/useAddToCart";
import AddToCart from "../Products/AddToCart/AddToCart";
import { useNavigate } from "react-router-dom";

export default function ProductDetail() {
  const classes = ProductDetailStyles();
  const addToCart = useAddToCart();
  const navigate = useNavigate();
  return (
    <Box className={classes.root}>
      <Box display="flex">
        <Button
          onClick={() => {
            navigate("/");
          }}
          variant="text"
          sx={{ padding: "0px", margin: "0px", left: "13px" }}
        >
          Home
        </Button>
        <ChevronRightIcon
          sx={{ color: "gray", fontSize: "medium", margin: "5px" }}
        />
        <Box className={classes.title}>Italian Pizza</Box>
      </Box>
      <Box display={{ xs: "block", md: "flex" }}>
        <Box className={classes.img}>
          <Box
            width="100%"
            height="100%"
            component="img"
            alt="product"
            src={product}
          />
        </Box>
        <Box>
          <Box className={classes.imgTitle}>Italian Pizza</Box>
          <Box className={classes.imgDiscription}>
            Freshly Baked Bread Filled with the Yummiest Cheese Blend to Satisfy
            your
          </Box>
          <Box mt={{ md: "25%" }}>
            <Box className={classes.favorite}>
              <FavoriteBorderIcon color="error" sx={{ marginTop: "2px" }} />
              <Button
                variant="text"
                sx={{
                  padding: "0px",
                  marginLeft: "5px",
                  fontSize: "large",
                }}
              >
                Add To Favorite
              </Button>
            </Box>
            <Box className={classes.price}>Rs. 1200</Box>
            <Box
              className={classes.addToCart}
              onClick={addToCart.toggleAddToCart}
            >
              Add to Cart
            </Box>
            {/* addToCart Start */}
            <AddToCart {...addToCart} />
            {/* AddToCart end */}
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
