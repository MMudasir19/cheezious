import { useState } from "react";

export const useAddToCart = () => {
  const [openAddToCart, setOpenAddToCart] = useState(false);
  const toggleAddToCart = () => {
    setOpenAddToCart(!openAddToCart);
  };

  return {
    toggleAddToCart,
    openAddToCart,
  };
};
