import { useState } from "react";

export const useOpenLocation = () => {
  const [openLocation, setOpenLocation] = useState(false);
  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState("");
  const [userCity, getUserCity] = useState("");
  const [areas, setAreas] = useState([]);
  const [selectedArea, setSelectedArea] = useState("");
  const [getSelectedArea, getUserArea] = useState("");
  const [isValid, setValid] = useState(false);

  const toggleLocation = () => {
    setOpenLocation(!openLocation);
  };

  const getCities = async () => {
    try {
      const response = await fetch(
        "http://192.168.100.97:9000/user_side/list_branches"
      );
      if (!response.ok) {
        throw new Error(
          `This is an HTTP error: The status is ${response.status}`
        );
      }
      let actualData = await response.json();
      setCities(await actualData.data);
    } catch (err) {
      setCities(null);
    }
  };

  const getArea = async () => {
    try {
      const response = await fetch(
        `http://192.168.100.97:9000/user_side/area/?city_id=${selectedCity}`
      );
      if (!response.ok) {
        throw new Error(
          `This is an HTTP error: The status is ${response.status}`
        );
      }
      let actualData = await response.json();
      setAreas(actualData.data);
    } catch (err) {
      setAreas(null);
    }
  };
  const handleChangeCity = (value) => {
    setSelectedCity(value.id);
    getUserCity(value.city);
  };

  const handleChangeArea = (value) => {
    setSelectedArea(value.area);
    getUserArea(value.area);
  };
  const validate = () => {
    if (selectedArea && selectedCity) {
      setValid(true);
    } else {
      setValid(false);
    }
  };
  const saveLocation = () => {
    sessionStorage.setItem("userArea", getSelectedArea);
    sessionStorage.setItem("userCity", userCity);
    getUserArea(selectedArea);
    getUserCity(selectedCity);
    toggleLocation();
  };

  return {
    openLocation,
    toggleLocation,
    cities,
    getCities,
    handleChangeCity,
    selectedCity,
    saveLocation,
    getArea,
    areas,
    handleChangeArea,
    selectedArea,
    isValid,
    validate,
  };
};
