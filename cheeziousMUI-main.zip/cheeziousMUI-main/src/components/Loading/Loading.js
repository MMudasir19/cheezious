import ClipLoader from "react-spinners/ClipLoader";

const override = {
  display: "flex",
  margin: "0 auto",
};

function Loading() {
  return <ClipLoader color="#DAA520" size={80} cssOverride={override} />;
}

export default Loading;
