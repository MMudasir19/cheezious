import * as React from "react";
import Alert from "@mui/material/Alert";
import Stack from "@mui/material/Stack";
import { Typography } from "@mui/material";
import { HeaderTheme } from "../../Theme";

export default function HeaderAlert() {
  return (
    <Stack>
      <Alert icon={false} variant="filled" severity="error">
        <Typography variant="h3" theme={HeaderTheme}>
          Sorry we are closed now. Will re-open at 11:00am
        </Typography>
      </Alert>
    </Stack>
  );
}
