import * as React from "react";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { Box } from "@mui/system";
import { aboutStyles } from "../../Theme";

export default function About() {
  const classes = aboutStyles();
  return (
    <>
      <Box className={classes.root}>
        <Box className={classes.main}>
          <Typography
            sx={{
              fontSize: { xs: "1.5rem", md: "2.5rem" },
              display: "flex",
              justifyContent: "center",
              fontWeight: 900,
            }}
          >
            Finest Taste Ever
          </Typography>
          <Accordion>
            <AccordionSummary
              sx={{ backgroundColor: "rgba(100, 84, 22, 1)", color: "white" }}
              expandIcon={<ExpandMoreIcon className={classes.icon} />}
              aria-controls="panel1a-content"
              id="panel1a-header"
            >
              <Typography>Accordion 1</Typography>
            </AccordionSummary>
            <AccordionDetails className={classes.contentDiv}>
              <Typography>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse malesuada lacus ex, sit amet blandit leo lobortis
                eget.
              </Typography>
            </AccordionDetails>
          </Accordion>
          <Accordion>
            <AccordionSummary
              sx={{ backgroundColor: "rgba(100, 84, 22, 1)", color: "white" }}
              expandIcon={<ExpandMoreIcon className={classes.icon} />}
              aria-controls="panel1a-content"
              id="panel1a-header"
            >
              <Typography>Accordion 2</Typography>
            </AccordionSummary>
            <AccordionDetails className={classes.contentDiv}>
              <Typography>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse malesuada lacus ex, sit amet blandit leo lobortis
                eget.
              </Typography>
            </AccordionDetails>
          </Accordion>
        </Box>
      </Box>
    </>
  );
}
