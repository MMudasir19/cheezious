import * as React from "react";
import List from "@mui/material/List";
import ListSubheader from "@mui/material/ListSubheader";
import { ListItem, ListItemText, Paper, Typography } from "@mui/material";
import { CategeoriesBarTheme } from "../../Theme";
import { useAPI } from "../Hooks/useContext";

export default function CategoriesBar() {
  const { data } = useAPI();
  return (
    <>
      <Paper
        style={{ position: "sticky", top: { xs: 65, sm: 77 } }}
        elevation={0}
      >
        <List>
          <Typography variant="div" theme={CategeoriesBarTheme}>
            {data.map((section) => (
              <ListSubheader>
                <ListItem disablePadding={true}>
                  <ListItemText
                    sx={{
                      display: "flex",
                      cursor: "pointer",
                      justifyContent: "center",
                      padding: "10px 25px",
                      borderRadius: "50px",
                      "&:hover": {
                        color: "black",
                        backgroundColor: "rgb(255, 203, 4)",
                      },
                    }}
                    primary={section.category}
                  />
                </ListItem>
              </ListSubheader>
            ))}
          </Typography>
        </List>
      </Paper>
    </>
  );
}
