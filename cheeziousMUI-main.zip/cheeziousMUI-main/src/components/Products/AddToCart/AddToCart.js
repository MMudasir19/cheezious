import * as React from "react";
import Box from "@mui/material/Box";
import product from "../../../images/product-detail.jpeg";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import CloseIcon from "@mui/icons-material/Close";
import { AddToCartStyles } from "../../../Theme";
import { TextField } from "@mui/material";
import RemoveIcon from "@mui/icons-material/Remove";
import AddIcon from "@mui/icons-material/Add";

export default function AddToCart({ openAddToCart, toggleAddToCart }) {
  const class1 = AddToCartStyles();
  return (
    <>
      {openAddToCart && (
        <Box className={class1.cartPopup}>
          <Box className={class1.cartPopupInner} />
          <Box className={class1.cartPopupMain}>
            <Box className={class1.cartClose}>
              <CloseIcon
                sx={{ display: { xs: "block", md: "none" } }}
                className={class1.close}
                onClick={toggleAddToCart}
              />
            </Box>
            <Box className={class1.cartContent}>
              <Box className={class1.addToCartImg}>
                <Box className={class1.cartImg}>
                  <Box component="span" className={class1.cartImgInner}>
                    <Box
                      component="img"
                      src={product}
                      alt="no img"
                      className={class1.cartImgIcon}
                    />
                  </Box>
                </Box>
                <Box className={class1.cartImgContent}>
                  <Box className={class1.cartItemTitle}>Pizza</Box>
                  <Box className={class1.cartItemDiscription}>
                    Freshly Baked Bread Filled with the Yummiest Cheese Blend to
                    Satisfy your
                  </Box>
                </Box>
              </Box>
              <Box className={class1.cartContentInner}>
                <Box className={class1.cartText}>
                  <Box className={class1.main}>
                    <Box className={class1.formTitle}>Variation</Box>
                    <Box display="flex">
                      <Box className={class1.formRequired}>(Required)</Box>
                      <CloseIcon
                        sx={{ display: { xs: "none", md: "block" } }}
                        className={class1.close}
                        onClick={toggleAddToCart}
                      />
                    </Box>
                  </Box>
                  <Box className={class1.cartSizes}>
                    <FormControl>
                      <RadioGroup
                        aria-labelledby="demo-radio-buttons-group-label"
                        defaultValue="female"
                        name="radio-buttons-group"
                        sx={{ margin: "10px" }}
                      >
                        <Box display="flex" width="100%">
                          <FormControlLabel
                            value="small"
                            control={
                              <Radio
                                sx={{
                                  color: "gray",
                                  "&.Mui-checked": {
                                    color: "#FFA500",
                                  },
                                }}
                              />
                            }
                          />
                          <Box className={class1.deals}>
                            <Box>Small</Box>
                            <Box>1200</Box>
                          </Box>
                        </Box>
                      </RadioGroup>
                    </FormControl>
                  </Box>
                </Box>
                <Box className={class1.actions}>
                  <Box className={class1.actionsInner}>
                    <Box display="flex">
                      <RemoveIcon
                        sx={{
                          color: "white",
                          verticalAlign: "middle",
                          backgroundColor: "red",
                          width: "1.5em",
                          height: "1.5em",
                          borderRadius: "5px",
                          "&:hover": {
                            color: "black",
                            backgroundColor: "rgb(255, 203, 4)",
                          },
                        }}
                      />
                      <TextField
                        size="small"
                        variant="outlined"
                        sx={{ width: "2.5em", margin: "0px 10px" }}
                      />
                      <AddIcon
                        sx={{
                          color: "white",
                          verticalAlign: "middle",
                          backgroundColor: "red",
                          width: "1.5em",
                          height: "1.5em",
                          borderRadius: "5px",
                          "&:hover": {
                            color: "black",
                            backgroundColor: "rgb(255, 203, 4)",
                          },
                        }}
                      />
                    </Box>
                    <Box className={class1.addBtn}>Add to Cart</Box>
                  </Box>
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
      )}
    </>
  );
}
