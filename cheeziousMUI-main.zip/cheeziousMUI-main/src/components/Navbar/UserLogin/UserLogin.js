import * as React from "react";
import PropTypes from "prop-types";
import DialogContent from "@mui/material/DialogContent";
import IconButton from "@mui/material/IconButton";
import {
  BootstrapDialog,
  BootstrapDialogTitle,
  MobileNumber,
} from "../../../Theme";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import "react-phone-input-2/lib/style.css";
import MuiPhoneNumber from "material-ui-phone-number";
import { Typography } from "@mui/material";
import Button from "@mui/material/Button";
import { Box } from "@mui/system";

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

export default function UserLogin({
  toggleUser,
  openUser,
  handleMbileNumber,
  saveMobileNumber,
}) {
  return (
    <>
      <div>
        <IconButton sx={{ padding: "0px 10px" }} onClick={toggleUser}>
          <AccountCircleIcon
            color="error"
            sx={{ fontSize: { xs: "25px", sm: "40px" } }}
          />
        </IconButton>
        <BootstrapDialog
          aria-labelledby="customized-dialog-title"
          open={openUser}
        >
          <BootstrapDialogTitle
            fontWeight={900}
            id="customized-dialog-title"
            onClose={toggleUser}
          >
            Enter your mobile number
          </BootstrapDialogTitle>
          <DialogContent dividers>
            <Typography gutterBottom>
              Please confirm your country code and enter your mobile number.
            </Typography>
            <MuiPhoneNumber
              defaultCountry={"pk"}
              regions={["asia"]}
              onChange={handleMbileNumber}
              sx={{
                margin: "15px 15px",
                width: "93%",
              }}
            />
            <Typography
              gutterBottom
              variant="h2"
              onClick={saveMobileNumber}
              theme={MobileNumber}
            >
              Continue
            </Typography>
          </DialogContent>
          <Box textAlign="center">
            <Button variant="text" onClick={toggleUser}>
              continue as a guest
            </Button>
          </Box>
        </BootstrapDialog>
      </div>
    </>
  );
}
