import * as React from "react";
import Drawer from "@mui/material/Drawer";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import IconButton from "@mui/material/IconButton";
import Badge from "@mui/material/Badge";
import { Box, Divider, Typography } from "@mui/material";
import emptyCart from "../../../images/cart-empty.svg";
import { emptyCartContent } from "../../../Theme";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

export default function Cart({ toggleCart, openCart }) {
  return (
    <div>
      <React.Fragment>
        <IconButton
          onClick={toggleCart}
          sx={{ padding: "0px 10px", display: { xs: "none", md: "block" } }}
        >
          <Badge color="success" badgeContent={0} showZero>
            <ShoppingCartIcon color="error" fontSize="large" />
          </Badge>
          <KeyboardArrowDownIcon color="error" fontSize="small" />
        </IconButton>
        <Drawer
          open={openCart}
          onClose={toggleCart}
          anchor="right"
          PaperProps={{
            elevation: 0,
            style: { borderTopLeftRadius: 15, borderBottomLeftRadius: 15 },
          }}
        >
          <Box component="div" sx={{ width: 400 }}>
            <Divider />
            <Typography variant="h5" theme={emptyCartContent}>
              Your Cart
            </Typography>
            <Divider />
            <Box
              sx={{
                height: 100,
                marginTop: 40,
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <Box
                  component="img"
                  sx={{
                    height: 60,
                    width: 60,
                  }}
                  alt="empty cart"
                  src={emptyCart}
                />
              </Box>
              <Typography variant="h6" theme={emptyCartContent}>
                Your cart is empty
              </Typography>
              <Typography variant="h6" theme={emptyCartContent}>
                Add an item and start making your order
              </Typography>
            </Box>
          </Box>
        </Drawer>
      </React.Fragment>
    </div>
  );
}
