import * as React from "react";
import PropTypes from "prop-types";
import Button from "@mui/material/Button";
import DialogContent from "@mui/material/DialogContent";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import Box from "@mui/material/Box";
import logo from "../../../images/logo.png";
import {
  BootstrapDialog,
  BootstrapDialogTitle,
  LocationContent,
  LocationStyles,
} from "../../../Theme";
import { Autocomplete, TextField } from "@mui/material";

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

export default function Location({
  openLocation,
  toggleLocation,
  cities,
  getCities,
  handleChangeCity,
  selectedCity,
  saveLocation,
  getArea,
  areas,
  handleChangeArea,
  selectedArea,
  isValid,
  validate,
}) {
  React.useEffect(() => {
    if (sessionStorage.getItem("userArea") === null) {
      toggleLocation();
    }
    getCities(); // eslint-disable-next-line
  }, []);

  React.useEffect(() => {
    validate();
    getArea();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedCity, selectedArea]);
  const classes = LocationStyles();
  return (
    <div>
      <Box display="flex" onClick={toggleLocation}>
        <IconButton>
          <LocationOnIcon
            color="error"
            sx={{ fontSize: { xs: "25px", sm: "40px" } }}
          />
        </IconButton>
        <Box>
          <Typography
            varient="div"
            fontWeight={600}
            sx={{ fontSize: { xs: "12px", sm: "medium" } }}
          >
            Deliver to
          </Typography>
          <Typography
            variant="div"
            sx={{ fontSize: { xs: "10px", sm: "small" } }}
          >
            {sessionStorage.getItem("userArea")
              ? sessionStorage.getItem("userArea")
              : "26 Number Bus Stop -RWP, Islamabad"}
          </Typography>
        </Box>
      </Box>
      <BootstrapDialog
        aria-labelledby="customized-dialog-title"
        open={openLocation}
      >
        {sessionStorage.getItem("userArea") === null ? (
          ""
        ) : (
          <BootstrapDialogTitle
            id="customized-dialog-title"
            onClose={toggleLocation}
          ></BootstrapDialogTitle>
        )}
        <DialogContent dividers>
          <Box display="flex" justifyContent="center">
            <Box
              component="img"
              height={100}
              width={100}
              alt="cheezious logo"
              src={logo}
            />
          </Box>
          <Box display="flex" justifyContent="center">
            <Box width={550}>
              <Typography gutterBottom variant="h1" theme={LocationContent}>
                Select your order type
              </Typography>
              <Typography align="center">
                <Button
                  size="large"
                  variant="contained"
                  sx={{
                    backgroundColor: "rgb(255, 203, 4)",
                    color: "black",
                    ml: 1,
                    "&.MuiButtonBase-root:hover": {
                      bgcolor: "rgb(255, 203, 4)",
                      color: "black",
                    },
                  }}
                >
                  Delivery
                </Button>
              </Typography>
              <Typography gutterBottom variant="h1" theme={LocationContent}>
                Please select your location
              </Typography>
              <Typography gutterBottom variant="span" theme={LocationContent}>
                Currently selected
              </Typography>
              <Box display="flex" justifyContent="center">
                <Typography gutterBottom variant="p" theme={LocationContent}>
                  {sessionStorage.getItem("userArea")
                    ? sessionStorage.getItem("userArea")
                    : " Your Location"}
                </Typography>
              </Box>
            </Box>
          </Box>
          <Autocomplete
            onChange={(event, value) => handleChangeCity(value)}
            id="cities"
            getOptionLabel={(cities) => `${cities.city}`}
            options={cities}
            sx={{ marginBottom: "15px" }}
            renderInput={(params) => (
              <TextField {...params} label="Select City" variant="outlined" />
            )}
            isOptionEqualToValue={(option, value) =>
              option.value === value.value
            }
          />
          <Autocomplete
            onChange={(event, value) => handleChangeArea(value)}
            id="cities"
            getOptionLabel={(areas) => `${areas.area}`}
            options={areas}
            renderInput={(params) => (
              <TextField {...params} label="Select Area" variant="outlined" />
            )}
            isOptionEqualToValue={(option, value) =>
              option.value === value.value
            }
          />
        </DialogContent>
        <Box textAlign="center" m={2}>
          <Box
            disabled={!isValid}
            width="100%"
            component="button"
            className={!isValid ? classes.disabled : classes.button}
            onClick={saveLocation}
          >
            SAVE
          </Box>
        </Box>
      </BootstrapDialog>
    </div>
  );
}
