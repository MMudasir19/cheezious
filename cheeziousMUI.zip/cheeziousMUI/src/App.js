import "./App.css";
import CategoriesBar from "./components/CategeoriesBar/CategoriesBar";
import HeaderAlert from "./components/HeaderAlert/HeaderAlert";
import { useTime } from "./components/Hooks/useTime";
import Navbar from "./components/Navbar/Navbar";
import Slider from "./components/Slider/Slider";
import { useAPI } from "./components/Hooks/useContext";
import Products from "./components/Products/Products";
import Loading from "./components/Loading/Loading";
import About from "./components/About/About";
import { Box } from "@mui/system";
import Footer from "./components/Footer/Footer";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ProductDetail from "./components/ProductDetail/ProductDetail";
function App() {
  const crrTime = useTime();
  const { isLoading } = useAPI();
  return (
    <>
      <BrowserRouter>
        {!isLoading ? (
          <>
            {crrTime.offTime < crrTime.time < crrTime.showTime ? (
              <HeaderAlert />
            ) : (
              ""
            )}
            <Navbar />
            <Routes>
              <Route
                index
                path="/"
                exact
                element={
                  <>
                    <Slider />
                    <CategoriesBar />
                    <Products />
                    <About />
                  </>
                }
              />
              <Route
                path="/product/:id"
                exact
                element={
                  <>
                    <ProductDetail />
                  </>
                }
              />
            </Routes>
            <Footer />
          </>
        ) : (
          <Box
            style={{
              width: "100%",
              height: "100vh",
              padding: "20%",
            }}
          >
            <Loading />
          </Box>
        )}
      </BrowserRouter>
    </>
  );
}

export default App;
