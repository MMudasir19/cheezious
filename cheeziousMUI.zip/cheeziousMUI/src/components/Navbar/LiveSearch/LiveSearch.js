import * as React from "react";
import PropTypes from "prop-types";
import DialogContent from "@mui/material/DialogContent";
import IconButton from "@mui/material/IconButton";
import Box from "@mui/material/Box";
import SearchTwoToneIcon from "@mui/icons-material/SearchTwoTone";
import { BootstrapDialog, BootstrapDialogTitle } from "../../../Theme";
import TextField from "@mui/material/TextField";
import { Typography } from "@mui/material";

BootstrapDialogTitle.propTypes = {
  children: PropTypes.node,
  onClose: PropTypes.func.isRequired,
};

export default function LiveSearch({ toggleSearch, openSearch }) {
  return (
    <>
      <div>
        <Box sx={{ display: "flex" }} onClick={toggleSearch}>
          <IconButton sx={{ padding: "0px 10px" }}>
            <SearchTwoToneIcon
              color="error"
              sx={{ fontSize: { xs: "25px", sm: "40px" } }}
            />
          </IconButton>
        </Box>
        <BootstrapDialog
          aria-labelledby="customized-dialog-title"
          open={openSearch}
        >
          <BootstrapDialogTitle
            id="customized-dialog-title"
            onClose={toggleSearch}
          >
            <Typography
              sx={{
                fontWeight: "800",
                fontSize: "1.5rem",
              }}
            >
              Search
            </Typography>
          </BootstrapDialogTitle>
          <DialogContent dividers>
            <Box sx={{ width: 550, height: 300 }}>
              <Box component="form" noValidate autoComplete="off">
                <TextField
                  sx={{ width: "100%" }}
                  id="outlined-basic"
                  label="Search"
                  variant="outlined"
                />
              </Box>
            </Box>
          </DialogContent>
        </BootstrapDialog>
      </div>
    </>
  );
}
