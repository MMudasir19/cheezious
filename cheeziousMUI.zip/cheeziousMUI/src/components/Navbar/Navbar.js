import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import logo from "../../images/logo.png";
import { Divider } from "@mui/material";
import Location from "./Location/Location";
import LiveSearch from "./LiveSearch/LiveSearch";
import { useOpenLocation } from "../../components/Hooks/useOpenLocation";
import { useLiveSearch } from "../../components/Hooks/useLiveSearch";
import UserLogin from "./UserLogin/UserLogin";
import { useLogin } from "../Hooks/useLogin";
import Cart from "./Cart/Cart";
import { useCart } from "../Hooks/useCart";

function Navbar() {
  const openLocation = useOpenLocation();
  const liveSearch = useLiveSearch();
  const user = useLogin();
  const cart = useCart();
  return (
    <>
      <AppBar
        position="sticky"
        sx={{ flexGrow: 1, padding: { xs: "0px 10px", md: "0px 100px" } }}
      >
        <Toolbar disableGutters>
          <Box sx={{ flexGrow: { xs: 1, md: 0.8 }, display: "flex" }}>
            {/* location popup start */}
            <Location {...openLocation} />
            {/* location popup end */}
          </Box>
          <Box
            sx={{
              p: { xs: 0, md: 10 },
              order: { xs: -1, md: 0 },
              flexGrow: { xs: 0, md: 1 },
            }}
          >
            <Box
              component="img"
              sx={{
                height: { xs: 40, sm: 60 },
                width: { xs: 40, sm: 60 },
              }}
              alt="cheezious logo"
              src={logo}
            />
          </Box>
          <Box sx={{ flexgrow: 0, display: "flex" }}>
            {/* LiveSearch start */}
            <LiveSearch {...liveSearch} />
            {/* LiveSearch end */}

            <Divider orientation="vertical" flexItem color="error" />
            {/* userLogin start */}
            <UserLogin {...user} />
            {/* userLogin end */}

            <Divider
              orientation="vertical"
              flexItem
              color="error"
              sx={{ display: { xs: "none", md: "block" } }}
            />
            {/* cart start */}
            <Cart {...cart} />
            {/* cart end */}
          </Box>
        </Toolbar>
      </AppBar>
    </>
  );
}
export default Navbar;
