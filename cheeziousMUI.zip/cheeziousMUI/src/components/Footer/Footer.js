import { Box } from "@mui/system";
import React from "react";
import logo from "../../images/logo.png";
import Typography from "@mui/material/Typography";
import LocalPhoneIcon from "@mui/icons-material/LocalPhone";
import MailIcon from "@mui/icons-material/Mail";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import googleLogin from "../../images/google-login.svg";
import fbLogin from "../../images/fb-login.svg";
import AccessAlarmIcon from "@mui/icons-material/AccessAlarm";
import fbFollow from "../../images/facebookLogin.webp";
import footerEnd from "../../images/footer-end-img.webp";
import instaFollow from "../../images/instagramLogin.webp";
import Divider from "@mui/material/Divider";
import CopyrightIcon from "@mui/icons-material/Copyright";
import { footerStyles } from "../../Theme";

export default function Footer() {
  const classes = footerStyles();
  return (
    <>
      <Box className={classes.root}>
        <Box className={classes.upper}>
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              margin: "1rem",
            }}
          >
            <Box
              height={150}
              width={150}
              component="img"
              alt="cheezious logo"
              src={logo}
            />
          </Box>
          <Box className={classes.upperInner}>
            <Box>
              <Typography
                varient="div"
                sx={{
                  fontWeight: "bolder",
                  fontSize: "large",
                  margin: "10px",
                }}
              >
                Cheezious
              </Typography>
              <Box display="flex" m="10px">
                <LocalPhoneIcon color="error" />
                <Typography
                  varient="span"
                  sx={{
                    fontWeight: "bolder",
                    fontSize: "large",
                    margin: "0px 5px",
                  }}
                >
                  Phone:
                </Typography>
                <Typography varient="span">051111446699</Typography>
              </Box>
              <Box display="flex" m="10px">
                <MailIcon color="error" />
                <Typography
                  varient="span"
                  sx={{
                    fontWeight: "bolder",
                    fontSize: "large",
                    margin: "0px 5px",
                  }}
                >
                  Email:
                </Typography>
                <Typography varient="span">support@cheezious.com</Typography>
              </Box>
              <Box display="flex" m="10px">
                <LocationOnIcon color="error" />
                <Typography
                  varient="span"
                  sx={{
                    fontWeight: "bolder",
                    fontSize: "large",
                    margin: "0px 5px",
                  }}
                >
                  Address:
                </Typography>
                <Typography varient="span">
                  26 number bus stop, Islamabad.
                </Typography>
              </Box>
              <Box display="flex" m="10px">
                <Box
                  component="a"
                  href="https://play.google.com/store/apps/details?id=com.blink.cheezious&hl=en&gl=US"
                >
                  <Box
                    sx={{ width: { xs: 120, sm: 150 } }}
                    component="img"
                    alt="cheezious logo"
                    src={googleLogin}
                  />
                </Box>
                <Box
                  component="a"
                  href="https://apps.apple.com/pk/app/cheezious/id1535315212"
                >
                  <Box
                    component="img"
                    sx={{ width: { xs: 120, sm: 150 } }}
                    alt="cheezious logo"
                    src={fbLogin}
                  />
                </Box>
              </Box>
            </Box>
            <Box>
              <Box display="flex" m="10px">
                <AccessAlarmIcon color="error" />
                <Typography
                  varient="span"
                  sx={{
                    fontWeight: "bolder",
                    fontSize: "large",
                    margin: "0px 5px",
                  }}
                >
                  Our Timings
                </Typography>
              </Box>
              <Box>
                <Box className={classes.rightInner}>
                  <Typography
                    varient="span"
                    sx={{ marginRight: { xs: 0, md: "30px" } }}
                  >
                    Monday - Thursday
                  </Typography>
                  <Typography varient="span">11:00 AM - 3:00 AM</Typography>
                </Box>
                <Box className={classes.rightInner}>
                  <Typography
                    varient="span"
                    sx={{ marginRight: { xs: 0, md: "30px" } }}
                  >
                    Friday
                  </Typography>
                  <Typography varient="span">2:00 PM - 3:00 AM</Typography>
                </Box>
                <Box className={classes.rightInner}>
                  <Typography
                    varient="span"
                    sx={{ marginRight: { xs: 0, md: "30px" } }}
                  >
                    Saturday - Sunday
                  </Typography>
                  <Typography varient="span">11:00 AM - 3:00 AM</Typography>
                </Box>
                <Box m={3} ml={1}>
                  <Typography varient="span" fontSize="large" fontWeight="800">
                    Follow us:
                  </Typography>
                  <Box display="flex">
                    <Box component="a" href="https://m.facebook.com/Cheezious/">
                      <Box
                        width={40}
                        component="img"
                        alt="cheezious logo"
                        src={fbFollow}
                      />
                    </Box>
                    <Box
                      component="a"
                      href="https://www.instagram.com/cheeziouspakistan/?igshid=YmMyMTA2M2Y%3D"
                    >
                      <Box
                        component="img"
                        width={40}
                        alt="cheezious logo"
                        src={instaFollow}
                      />
                    </Box>
                  </Box>
                </Box>
              </Box>
            </Box>
          </Box>
        </Box>
        <Box className={classes.lower}>
          <Divider color="black" sx={{ borderBottomWidth: 2 }} />
          <Box display="flex" justifyContent="center" m="1.5rem">
            <CopyrightIcon />
            <Typography varient="span" ml={1}>
              2022 Powered by
              <Box component="a" sx={{ textDecoration: "underline" }} ml={1}>
                Blink Co.
              </Box>
            </Typography>
          </Box>
          <Box
            component="img"
            width={100}
            alt="cheezious logo"
            src={footerEnd}
          />
        </Box>
      </Box>
    </>
  );
}
