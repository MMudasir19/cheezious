import { useState } from "react";

export const useLogin = () => {
  const [openUser, setOpenUser] = useState(false);
  const [mobileNumber, setMobileNumber] = useState("");
  const toggleUser = () => {
    setOpenUser(!openUser);
  };
  const handleMbileNumber = (value) => {
    setMobileNumber(value);
  };

  const saveMobileNumber = () => {
    sessionStorage.setItem("mobileNumber", mobileNumber);
    setOpenUser(!openUser);
  };
  return {
    toggleUser,
    openUser,
    handleMbileNumber,
    saveMobileNumber,
  };
};
