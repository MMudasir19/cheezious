import React from "react";
import { useAPI } from "../Hooks/useContext";
import Typography from "@mui/material/Typography";
import Loading from "../Loading/Loading";
import product from "../../images/product-detail.jpeg";
import { Box } from "@mui/system";
import { ProductStyles } from "../../Theme";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import AddToCart from "./AddToCart/AddToCart";
import { useAddToCart } from "../Hooks/useAddToCart";
import { useNavigate } from "react-router-dom";

const Products = () => {
  const navigate = useNavigate();
  const { data, isLoading } = useAPI();
  const classes = ProductStyles();
  const addToCart = useAddToCart();
  return (
    <Box>
      {!isLoading ? (
        <Box>
          {data.map((item) => {
            return (
              <>
                <Box key={item.id}>
                  <Box>{item.category}</Box>
                  <Box
                    style={{
                      display: "flex",
                      flexWrap: "wrap",
                      margin: "1rem 5rem",
                    }}
                  >
                    {item[item.category].map((item) => {
                      return (
                        <>
                          <Box m={10}>
                            <Box className={classes.root}>
                              <Box m="20px">
                                <Box
                                  onClick={() => {
                                    navigate("/product/:id");
                                  }}
                                  width="100%"
                                  height="100%"
                                  display="flex"
                                  justifyContent="flex-end"
                                >
                                  <Box
                                    width="100%"
                                    height="100%"
                                    component="img"
                                    alt="product"
                                    src={product}
                                  />

                                  <FavoriteBorderIcon
                                    fontSize="large"
                                    color="error"
                                    sx={{
                                      position: "absolute",
                                    }}
                                  />
                                </Box>
                                <Box
                                  textAlign="center"
                                  onClick={() => {
                                    navigate("/product/:id");
                                  }}
                                >
                                  <Typography
                                    fontSize="1.2rem"
                                    fontWeight={800}
                                  >
                                    Italian Pizza
                                  </Typography>
                                  <Typography
                                    color="inherit"
                                    fontSize="13px"
                                    fontWeight={400}
                                  >
                                    Freshly Baked Bread Filled with the Yummiest
                                    Cheese Blend to Satisfy your
                                  </Typography>
                                  <Typography
                                    color="error"
                                    fontWeight={900}
                                    fontSize="15px"
                                    mt={2}
                                  >
                                    Rs. 1300
                                  </Typography>
                                </Box>
                                <Box
                                  textAlign="center"
                                  onClick={addToCart.toggleAddToCart}
                                >
                                  <Box
                                    component="div"
                                    className={classes.button}
                                  >
                                    Add to Cart
                                  </Box>
                                </Box>
                                {/* AddToCart start */}
                                <AddToCart {...addToCart} />
                                {/* AddToCart end */}
                              </Box>
                            </Box>
                          </Box>
                        </>
                      );
                    })}
                  </Box>
                </Box>
              </>
            );
          })}
        </Box>
      ) : (
        <Loading />
      )}
    </Box>
  );
};

export default Products;
