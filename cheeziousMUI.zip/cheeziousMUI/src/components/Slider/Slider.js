import React from "react";
import Carousel from "react-material-ui-carousel";
import Items from "./Items";
import img1 from "../../images/slider1.png";
import img2 from "../../images/slider2.jpeg";
import img3 from "../../images/slider3.jpeg";

const sliderImages = [
  {
    id: 1,
    img: img1,
  },
  {
    id: 2,
    img: img2,
  },
  {
    id: 3,
    img: img3,
  },
];
export default function Slider() {
  return (
    <Carousel
      animation="slide"
      navButtonsAlwaysVisible={true}
      duration={800}
      indicatorIconButtonProps={{
        style: {
          padding: "5px 10px",
          color: "grey[500]",
        },
      }}
      indicatorContainerProps={{
        style: {
          marginTop: "3%",
          textAlign: "center",
        },
      }}
      navButtonsProps={{
        style: {
          backgroundColor: "#F08080",
          borderRadius: "20px",
          padding: "20px 10px",
        },
      }}
      fullHeightHover={false}
    >
      {sliderImages.map((item) => (
        <>
          <Items key={item.id} item={item} />
        </>
      ))}
    </Carousel>
  );
}
