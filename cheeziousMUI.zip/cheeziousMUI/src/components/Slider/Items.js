import { Box, Paper } from "@mui/material";

export default function Items({ item }) {
  return (
    <Paper
      sx={{
        margin: { xs: "3% 2%", sm: "3% 4%" },
      }}
      elevation={0}
    >
      <Box
        component="img"
        alt="no img"
        src={item.img}
        sx={{
          display: "flex",
          width: "100%",
          height: { xs: "20vh", md: "45vh" },
          justifyContent: "center",
        }}
      />
    </Paper>
  );
}
