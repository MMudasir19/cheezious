import { createTheme } from "@mui/material/styles";
import { styled } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import CloseIcon from "@mui/icons-material/Close";
import IconButton from "@mui/material/IconButton";
import { grey } from "@mui/material/colors";
import { makeStyles } from "@mui/styles";

export const theme = createTheme({
  components: {
    MuiAlert: {
      styleOverrides: {
        root: {
          height: { xs: "2rem", sm: "2.5rem" },
          padding: "0px",
          display: "flex",
          justifyContent: "center",
          borderRadius: "0px",
        },
      },
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          width: "100%",
          backgroundColor: "rgb(255, 203, 4)",
          color: "black",
          fontSize: "1rem",
          height: "5rem",
          margin: "0px",
          borderRadius: "0px",
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          fontSize: "0.8rem",
          marginBottom: "20px",
          color: "grey",
          "&:hover": {
            textDecoration: "underline",
            textDecorationColor: "rgb(255, 203, 4)",
            color: "rgb(255, 203, 4)",
          },
        },
      },
    },
  },
});

export const HeaderTheme = createTheme();

HeaderTheme.typography.h3 = {
  fontSize: "1rem",
  "@media (max-width:600px)": {
    fontSize: "0.7rem",
  },
  [HeaderTheme.breakpoints.up("sm")]: {
    fontSize: "1rem",
  },
};

export const emptyCartContent = createTheme();

emptyCartContent.typography.h5 = {
  fontSize: "1rem",
  margin: "15px",
  fontWeight: 800,
};
emptyCartContent.typography.h6 = {
  fontSize: "1rem",
  display: "flex",
  justifyContent: "center",
  fontWeight: 500,
  color: grey[500],
};

export const LocationContent = createTheme();

LocationContent.typography.h1 = {
  fontWeight: "bold",
  fontSize: "1.3rem",
  display: "flex",
  justifyContent: "center",
  padding: "5px 0px",
};
LocationContent.typography.span = {
  fontSize: "1rem",
  display: "flex",
  justifyContent: "center",
  padding: "5px 0px",
};
LocationContent.typography.p = {
  fontSize: "1rem",
  backgroundColor: "rgb(255, 203, 4)",
  padding: "5px 10px",
  borderRadius: "20px",
};
LocationContent.typography.h2 = {
  fontSize: "1rem",
  color: "white",
  display: "flex",
  margin: "0px 15px",
  cursor: "pointer",
  justifyContent: "center",
  backgroundColor: "red",
  padding: "10px 20px",
  borderRadius: "5px",
  "&:hover": {
    color: "black",
    backgroundColor: "rgb(255, 203, 4)",
  },
};

export const MobileNumber = createTheme();
MobileNumber.typography.h2 = {
  fontSize: "1rem",
  color: "white",
  display: "flex",
  margin: "10px 15px",
  cursor: "pointer",
  justifyContent: "center",
  backgroundColor: "red",
  padding: "10px 20px",
  borderRadius: "5px",
  "&:hover": {
    color: "black",
    backgroundColor: "rgb(255, 203, 4)",
  },
};
MobileNumber.typography.h3 = {
  fontSize: "1rem",
  color: "white",
  display: "flex",
  margin: "10px 15px",
  cursor: "pointer",
  justifyContent: "center",
  backgroundColor: "grey[800]",
  padding: "10px 20px",
  borderRadius: "5px",
};

export const CategeoriesBarTheme = createTheme();

CategeoriesBarTheme.typography.div = {
  borderRadius: "5px",
  padding: "0px 20px",
  backgroundColor: "grey[800]",
  cursor: "pointer",
  display: "flex",
  fontSize: "1rem",
  margin: "0px",
  flexWrap: "nowrap",
  overflowX: "scroll",
  "@media (max-width:600px)": {
    fontSize: "0.7rem",
  },
  [CategeoriesBarTheme.breakpoints.up("md")]: {
    fontSize: "0.6rem",
    margin: "1rem 6rem",
    flexWrap: "wrap",
    overflowX: "hidden",
  },
};

export const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

export function BootstrapDialogTitle(props) {
  const { children, onClose, ...other } = props;

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: "absolute",
            right: 8,
            top: 8,
            backgroundColor: "grey",
            color: "white",
            borderRadius: "5px",
            "&:hover": {
              color: "white",
              backgroundColor: "grey",
            },
          }}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </DialogTitle>
  );
}

export const aboutStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexDirection: "column",
    backgroundColor: "rgb(255, 203, 4)",
    margin: "0px",
    [theme.breakpoints.up("sm")]: {
      margin: "5rem",
    },
    borderRadius: "10px",
  },
  main: {
    display: "flex",
    flexDirection: "column",
    margin: "3rem",
  },
  contentDiv: {
    backgroundColor: "black",
    color: "white",
  },
  heading: {
    fontSize: "1rem",
    fontWeight: 800,
  },
  icon: {
    color: "white",
  },
}));

export const footerStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexDirection: "column",
    margin: "0px",
    [theme.breakpoints.up("md")]: {
      margin: "7rem",
      marginBottom: "0px",
    },
  },
  upper: {
    display: "block",
    [theme.breakpoints.up("md")]: {
      display: "flex",
    },
  },
  upperInner: {
    display: "block",
    justifyContent: "space-between",
    width: "100%",
    [theme.breakpoints.up("md")]: {
      display: "flex",
    },
  },
  rightInner: {
    display: "flex",
    justifyContent: "space-between",
    fontSize: "1rem",
    fontWeight: 800,
    margin: "10px",
  },
}));

export const ProductStyles = makeStyles(() => ({
  root: {
    cursor: "pointer",
    margin: 2,
    maxWidth: "18rem",
    borderRadius: "20px",
    border: "2px solid white",

    "&:hover": {
      border: "2px solid rgb(255, 203, 4)",
    },
  },
  button: {
    fontSize: "1rem",
    fontWeight: 500,
    backgroundColor: "red",
    margin: "10px",
    color: "white",
    padding: "15px",
    borderRadius: "5rem",
    display: "inline-block",
    "&:hover": {
      backgroundColor: "rgb(255, 203, 4)",
      color: "black",
    },
  },
}));

export const LocationStyles = makeStyles(() => ({
  button: {
    fontSize: "1rem",
    color: "white",
    backgroundColor: "red",
    padding: "12px",
    fontWeight: 700,
    borderRadius: "5px",
    cursor: "pointer",
    "&:hover": {
      backgroundColor: "rgb(255, 203, 4)",
      color: "black",
    },
  },
  disabled: {
    fontSize: "1rem",
    color: "white",
    backgroundColor: "grey",
    padding: "12px",
    fontWeight: 700,
    borderRadius: "5px",
    cursor: "pointer",
  },
}));

export const AddToCartStyles = makeStyles((theme) => ({
  cartPopup: {
    position: "fixed",
    zIndex: 1300,
    inset: "0px",
  },
  cartPopupInner: {
    opacity: 1,
    backdropFilter: "blur(10px)",
    transition: "opacity 225ms cubic-bezier(0.4, 0, 0.2, 1) 0ms",
    position: "fixed",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    inset: "0px",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    zIndex: -1,
  },
  cartPopupMain: {
    [theme.breakpoints.up("sm")]: {
      outline: "none",
      backgroundColor: "rgb(255, 255, 255)",
      borderRadius: "8px",
      maxHeight: "90vh",
      maxWidth: "100vw",
      minHeight: "100px",
      width: "80%",
      overflowY: "auto",
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
    },
    outline: "none",
    backgroundColor: "rgb(255, 255, 255)",
    borderRadius: "8px",
    overflowY: "auto",
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    margin: 0,
    padding: 0,
    width: "100%",
    maxHeight: "60vh",
    maxWidth: "100vw",
    minHeight: "100px",
  },
  cartClose: {
    position: "absolute",
    top: "10px",
    right: "10px",
    zIndex: 1,
  },
  cartContent: {
    boxSizing: "border-box",
    display: "block",
    [theme.breakpoints.up("md")]: {
      display: "flex",
    },
    flexFlow: "row",
    width: "100%",
  },
  cartContentInner: {
    [theme.breakpoints.up("md")]: {
      flexBasis: "50%",
      maxWidth: "100%",
      position: "relative",
      maxHeight: "90vh",
      minHeight: "90vh",
    },
    flexBasis: "100%",
    flexGrow: 0,
    maxWidth: "100%",
    maxHeight: "35vh",
    minHeight: "35vh",
  },
  addToCartImg: {
    flexBasis: "100%",
    flexGrow: 0,
    position: "relative",
    boxSizing: "border-box",
    margin: "0px",
    maxHeight: "25vh",
    minHeight: "25vh",
    [theme.breakpoints.up("md")]: {
      minHeight: "90vh",
      flexBasis: "70%",
      position: "relative",
      boxSizing: "border-box",
      margin: "0px",
    },
  },
  cartImg: {
    [theme.breakpoints.up("md")]: {
      flexBasis: "50%",
      maxWidth: "100%",
      position: "absolute",
      inset: "0px",
      width: "100%",
    },
    flexBasis: "100%",
    maxWidth: "100%",
    position: "absolute",
    inset: "0px",
    width: "100%",
  },
  cartImgInner: {
    [theme.breakpoints.up("md")]: {
      flexBasis: "50%",
      maxWidth: "100%",
      display: "block",
      overflow: "hidden",
      width: "100%",
      height: "100%",
      background: "none",
      opacity: 1,
      border: "0px",
      margin: "0px",
      padding: "0px",
      position: "absolute",
      inset: "0px",
    },
    flexBasis: "100%",
    maxWidth: "100%",
    display: "block",
    overflow: "hidden",
    width: "100%",
    background: "none",
    opacity: 1,
    border: "0px",
    margin: "0px",
    padding: "0px",
    position: "absolute",
    inset: "0px",
  },
  cartImgIcon: {
    [theme.breakpoints.up("md")]: {
      flexBasis: "50%",
      position: "absolute",
      inset: "0px",
      boxSizing: "border-box",
      padding: "0px",
      border: "none",
      margin: "auto",
      display: "block",
      width: "0px",
      height: "0px",
      minWidth: "100%",
      maxWidth: "100%",
      minHeight: "100%",
      maxHeight: "100%",
      objectFit: "cover",
    },
    flexBasis: "100%",
    maxWidth: "100%",
    position: "absolute",
    inset: "0px",
    boxSizing: "border-box",
    padding: "0px",
    border: "none",
    margin: "auto",
    display: "block",
    width: "0px",
    height: "0px",
    minWidth: "100%",
    minHeight: "100%",
    maxHeight: "100%",
    objectFit: "cover",
  },
  cartImgContent: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    background:
      " linear-gradient( 0deg, rgba(0, 0, 0, 0.85), rgba(0, 0, 0, 0.35) 50%,transparent)",
    display: "flex",
    flexDirection: "column",
    padding: "10px 15px",
    color: "#fff",
  },
  cartItemTitle: {
    fontSize: "34px",
    fontWeight: "bold",
    marginBottom: "6px",
    color: "#fff",
  },
  cartItemDiscription: {
    fontSize: "14px",
    fontWeight: "normal",
    marginBottom: "10px",
    color: "#fff",
  },
  cartText: {
    height: "90vh",
    overflowY: "auto",
    paddingBottom: "60px",
  },
  cartSizes: {
    display: "flex",
    flexFlow: "column wrap",
  },
  main: {
    display: "flex",
    justifyContent: "space-between",
    padding: "10px",
  },
  formTitle: {
    color: "black",
    fontWeight: 800,
    fontFamily: "sans-serif",
    fontSize: "large",
  },
  formRequired: {
    color: "white",
    backgroundColor: "red",
    padding: "2px",
    borderRadius: "3px",
    marginRight: "2px",
  },
  close: {
    color: "white",
    backgroundColor: "grey",
    padding: "2px",
    borderRadius: "2px",
  },
  deals: {
    margin: "10px",
    display: "flex",
    width: "100%",
    justifyContent: "space-between",
  },
  actions: {
    bottom: 0,
    display: "flex",
    position: "absolute",
    justifyContent: "space-between",
    width: "90%",
    margin: "20px",
  },
  actionsInner: {
    width: "100%",
    display: "flex",
    justifyContent: "space-between",
  },
  addBtn: {
    textAlign: "center",
    color: "white",
    backgroundColor: "red",
    padding: "10px",
    borderRadius: "5px",
    "&:hover": {
      color: "black",
      backgroundColor: "rgb(255, 203, 4)",
    },
  },
}));

export const ProductDetailStyles = makeStyles(() => ({
  root: {
    [theme.breakpoints.up("md")]: {
      margin: "5rem",
    },
    margin: "5rem 0rem",
  },
  title: {
    color: "rgb(255, 203, 4)",
  },
  img: {
    [theme.breakpoints.up("md")]: {
      width: "25em",
      height: "25em",
    },
  },
  imgTitle: {
    margin: "0px 10px 20px 10px",
    fontFamily: "sans-serif",
    fontSize: "x-large",
  },
  imgDiscription: {
    margin: "10px",
    fontFamily: "sans-serif",
    fontSize: "medium",
    color: "gray",
  },
  favorite: {
    display: "flex",
    margin: "10px",
    bottom: "50%",
  },
  price: {
    fontFamily: "sans-serif",
    fontSize: "large",
    fontWeight: 800,
    margin: "10px",
  },
  addToCart: {
    [theme.breakpoints.up("md")]: {
      display: "inline-block",
    },
    textAlign: "center",
    fontFamily: "sans-serif",
    fontSize: "large",
    fontWeight: 800,
    margin: "10px",
    color: "white",
    backgroundColor: "red",
    padding: "10px",
    borderRadius: "10px",
    cursor: "pointer",
    "&:hover": {
      color: "black",
      backgroundColor: "rgb(255, 203, 4)",
    },
  },
}));
