import slider1 from "../../images/slider1.png";
import slider2 from "../../images/slider2.jpeg";
import slider3 from "../../images/slider3.jpeg";
 // eslint-disable-next-line
export default [
    {
    title:"slider1",
    icon:slider1,
}
   ,{
    title:"slider2",
    icon:slider2,
}
  ,{
    title:"slider3",
    icon:slider3,
}
]