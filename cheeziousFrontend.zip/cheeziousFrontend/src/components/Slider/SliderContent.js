import React from "react";

export default function SliderContent({ activeIndex, imageSlider }) {
  return (
    <section className="slider-img">
      {imageSlider.map((slide, index) => (
        <div
          key={index}
          className={index === activeIndex ? "slides active" : "inactive"}
        >
          <img className="slide-img" src={slide.icon} alt="no img"/>
        </div>
      ))}
    </section>
  );
}
