import React, { useState, useEffect } from "react";
import Dots from "./Dots";
import imageSlider from "./imageSlider";
import "./slider.css";

export default function Slider() {
  const len = imageSlider.length - 1;
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex(activeIndex === len ? 0 : activeIndex + 1);
    }, 5000);
    return () => {
      clearInterval(interval);
    }; // eslint-disable-next-line
  }, [activeIndex]);
  return (
    <>
      <div className="slider-container">
        <div className="prev-arrow">
          <div className="prev-inner">
            <span
              className="prev"
              onClick={() =>
                setActiveIndex(activeIndex < 1 ? len : activeIndex - 1)
              }
            >
              &#10094;
            </span>
          </div>
        </div>
        <div className="next-arrow">
          <div className="next-inner">
            <span
              className="next"
              onClick={() =>
                setActiveIndex(activeIndex === len ? 0 : activeIndex + 1)
              }
            >
              &#10095;
            </span>
          </div>
        </div>
        <div className="slider-img">
          {imageSlider.map((slide, index) => (
            <div
              key={index}
              className={index === activeIndex ? "slidesActive" : "inactive"}
            >
              <img className="slide-img" src={slide.icon} alt="no img" />
            </div>
          ))}
        </div>
        <Dots
          activeIndex={activeIndex}
          imageSlider={imageSlider}
          onclick={(activeIndex) => setActiveIndex(activeIndex)}
        />
      </div>
    </>
  );
}
