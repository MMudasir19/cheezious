import React from "react";
import "./CategoryItems.css";
import CategoryProduct from "./CategoryProduct/CategoryProduct";

export default function CategoryItems(props) {
  return (
    <>
      <div className="category-items">
        {props.data.map((item, index) => {
          return (
            <div id={item.category} key={index}>
              <div className="item-main">
                <div className="item-inner"></div>
                <div className="item-heading">
                  <h1 className="heading">{item.category}</h1>
                  {item[item.category] ? (
                    <div className="card_main">
                      {item[item.category].map((item) => {
                        return (
                          <>
                            <CategoryProduct
                              item={item}
                              onAdd={props.onAdd}
                              onRemove={props.onRemove}
                              cartItems={props.cartItems.find(
                                (x) => x.id === item.id
                              )}
                            />
                          </>
                        );
                      })}
                    </div>
                  ) : (
                    ""
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}
