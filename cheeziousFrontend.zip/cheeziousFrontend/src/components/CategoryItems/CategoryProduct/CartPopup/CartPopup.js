import React, { useState, useEffect } from "react";
import "./CartPopup.css";
import cartClose from "../../../../images/close.png";
import spinner from "../../../../images/spinner.gif";
import { FormControlLabel, Radio, RadioGroup } from "@mui/material";
import { FormControl } from "@mui/material";

export default function CartPopup(props) {
  const [data, setData] = useState([]);
  const [extraVisible, setExtraVisible] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const url = `http://192.168.100.63:9000/user_side/list_product_deals?product_id=${props.selectedItem}`;
  const getData = async () => {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(
          `This is an HTTP error: The status is ${response.status}`
        );
      }
      let actualData = await response.json();
      setData(actualData.data);
      setError(null);
    } catch (err) {
      setError(err.message);
      setData(null);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    getData();
    // eslint-disable-next-line
  }, []);

  const [variationValue, setVariationValue] = useState("");
  const [extraDealsValue, setExtraDealsValue] = useState("");
  const handleChangeVariation = (event, value) => {
    setVariationValue(value);
  };
  const handleChangeExtraDeals = (event, value) => {
    setExtraDealsValue(value);
  };

  const [isValid, setValid] = useState(false);
  const validate = () => {
    if (variationValue) {
      setValid(true);
    } else {
      setValid(false);
    }
  };
  useEffect(() => {
    validate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [variationValue]);
  return (
    <>
      {loading ? (
        <div className="popup-box">
          <div>
            <img
              style={{ width: "5rem", height: "6rem" }}
              src={spinner}
              alt="Loading..."
            />
            <div>Loading...</div>
          </div>
        </div>
      ) : (
        <>
          {data.map((item, index) => {
            return (
              <div className="cart-popup" key={index}>
                <div className="cart-popup-inner"></div>
                <div></div>
                <div className="cart-popup-main">
                  <div
                    className="cart-close"
                    onClick={() => {
                      props.togglePopupCart();
                    }}
                  >
                    <img src={cartClose} alt="no img" className="close-img" />
                  </div>
                  <div className="cart-content">
                    <div className="addtocart-img">
                      <div className="cart-image">
                        <span className="cart-image-inner">
                          <img
                            src={item.image}
                            alt="no img"
                            className="cart-image-icon"
                          />
                        </span>
                      </div>
                      <div className="cart-img-content">
                        <span className="cart-img-heading">{item.title}</span>
                        <span className="cart-img-description">
                          {item.discription}
                        </span>
                      </div>
                    </div>
                    <div className="cart-content-inner">
                      <div className="cart-text">
                        <div className="cart-text-required">
                          <span className="cart-required-heading">
                            Variation
                          </span>
                          <span className="cart-required-tag">(Required)</span>
                        </div>
                        <div className="cart-sizes">
                          <FormControl>
                            <RadioGroup
                              aria-labelledby="demo-radio-buttons-group-label"
                              value={variationValue ? variationValue : " "}
                              onChange={handleChangeVariation}
                            >
                              {item.variation.map((item, index) => {
                                return (
                                  <>
                                    <div
                                      className="cart-sizes-inner"
                                      key={index}
                                    >
                                      <FormControlLabel
                                        name={item.discription}
                                        id={item.id}
                                        value={item.price}
                                        control={
                                          <Radio
                                            sx={{
                                              color: "gray",
                                              "&.Mui-checked": {
                                                color: "#FFA500",
                                              },
                                            }}
                                          />
                                        }
                                        onClick={() => {
                                          setExtraVisible(true);
                                        }}
                                      />
                                      <div className="cart-data">
                                        <span className="cart-data-title">
                                          {item.discription}
                                        </span>
                                        <span className="cart-data-price">
                                          {item.price}
                                        </span>
                                      </div>
                                    </div>
                                  </>
                                );
                              })}
                            </RadioGroup>
                          </FormControl>
                        </div>
                        {extraVisible && (
                          <div>
                            <div className="cart-text-required">
                              <span className="cart-required-heading">
                                Extra Topping
                              </span>
                            </div>
                            <div className="cart-sizes">
                              <FormControl>
                                <RadioGroup
                                  aria-labelledby="demo-radio-buttons-group-label"
                                  value={
                                    extraDealsValue ? extraDealsValue : " "
                                  }
                                  onChange={handleChangeExtraDeals}
                                >
                                  {item.extra_deals.map((item, index) => {
                                    return (
                                      <>
                                        <div className="cart-sizes-inner">
                                          <FormControlLabel
                                            name={item.discription}
                                            key={index}
                                            id={item.id}
                                            value={item.price ? item.price : ""}
                                            control={
                                              <Radio
                                                sx={{
                                                  color: "gray",
                                                  "&.Mui-checked": {
                                                    color: "#FFA500",
                                                  },
                                                }}
                                              />
                                            }
                                          />
                                          <div className="cart-data">
                                            <span className="cart-data-title">
                                              {item.discription}
                                            </span>
                                            <span className="cart-data-price">
                                              {item.price}
                                            </span>
                                          </div>
                                        </div>
                                      </>
                                    );
                                  })}
                                </RadioGroup>
                              </FormControl>
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="cart-add">
                        <div>
                          <button
                            className="cart-btn"
                            onClick={() => {
                              props.onRemove(item);
                            }}
                          >
                            -
                          </button>

                          <div className="cart-increment">
                            <div className="cart-increment-inner">
                              {props.cartItems ? (
                                <input
                                  className="cart-increment-type"
                                  value={props.cartItems.qty}
                                  readOnly
                                />
                              ) : (
                                <input
                                  className="cart-increment-type"
                                  value="0"
                                  readOnly
                                />
                              )}
                            </div>
                          </div>
                          <button
                            className="cart-btn"
                            onClick={() => {
                              props.onAdd(item);
                            }}
                          >
                            +
                          </button>
                        </div>
                        <button
                          disabled={!isValid}
                          onClick={() => {
                            props.togglePopupCart();
                          }}
                          className={
                            !isValid ? "cart-add-btn-disabled" : "cart-add-btn"
                          }
                        >
                          Add To Cart
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </>
      )}
      {error && (
        <div>{`There is a problem fetching the post data - ${error}`}</div>
      )}
    </>
  );
}
