import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import heart from "../../../images/heart.png";
import CartPopup from "./CartPopup/CartPopup";

export default function CategoryProduct(props) {
  const navigate = useNavigate();

  useEffect(() => {
    return () => {
      setIsOpenCart(false);
    };
  }, []);
  const [isOpenCart, setIsOpenCart] = useState(false);
  const [selectedItem, setSelectedItem] = useState([]);
  const togglePopupCart = () => {
    setIsOpenCart(!isOpenCart);
    setSelectedItem(props.item.id);
  };

  return (
    <>
      <div className="card" key={props.item.id}>
        <div
          className="card-inner"
          onClick={() => {
            navigate(`/product/${props.item.id}/${props.item.title}`);
          }}
        >
          <div className="card-img">
            <div className="card-image">
              <img className="item-img" src={props.item.image} alt="" />
            </div>
            <img className="heart" src={heart} alt="no img" />
          </div>
          <div className="card-text">
            <span className="item-name">{props.item.title}</span>
            <p className="item-description">{props.item.discription}</p>
            <div className="price-tag"></div>
            <div className="price">
              <span>{props.item.price}</span>
            </div>
          </div>
        </div>
        {props.cartItems ? (
          <div className="item-btn-outer">
            <div className="item-btn-outer1">
              <button className="cart-item-btn" onClick={togglePopupCart}>
                -<span className="item-space"></span>
              </button>
              <div className="cart-item-qty">{props.cartItems.qty}</div>
              <button className="cart-item-btn" onClick={togglePopupCart}>
                +<span className="item-space"></span>
              </button>
            </div>
          </div>
        ) : (
          <div className="item-btn-outer">
            <button className="item-btn" onClick={togglePopupCart}>
              Add to Cart
              <span className="item-space"></span>
            </button>
          </div>
        )}
      </div>
      {isOpenCart && (
        <>
          <CartPopup
            cartItems={props.cartItems}
            onRemove={props.onRemove}
            setIsOpenCart={setIsOpenCart}
            selectedItem={selectedItem}
            togglePopupCart={togglePopupCart}
            onAdd={props.onAdd}
          />
        </>
      )}
    </>
  );
}
