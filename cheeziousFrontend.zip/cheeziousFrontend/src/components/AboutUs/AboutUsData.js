const data = [
  {
    title: "cheezious",
    content: "loreum ipsum cheezious is the best.",
  },
  {
    title: "cheezious",
    content: "loreum ipsum cheezious is the best.",
  },
  {
    title: "cheezious",
    content: "loreum ipsum cheezious is the best.",
  },
];

export default data;
