import React, { useState } from "react";
import "./AboutUs.css";
import data from "./AboutUsData";

export default function AboutUs() {
  const [selected, setselected] = useState(null);
  const toggle = (i) => {
    if (selected === i) {
      return setselected(null);
    }
    setselected(i);
  };
  return (
    <>
      <div className="about-us">
        <div className="about-us-inner">
          <h1 className="about-us-heading">Finest Taste Ever</h1>
          {data.map((item, i) => {
            return (
              <div className={selected === i ? "about show" : "about"} key={i}>
                <div className="title" onClick={() => toggle(i)}>
                  <h4>{item.title}</h4>
                  <span>{selected === i ? "-" : "+"}</span>
                </div>
                <div className={selected === i ? "content show" : "content"}>
                  <p>{item.content}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <div className="footer-space"></div>
    </>
  );
}
