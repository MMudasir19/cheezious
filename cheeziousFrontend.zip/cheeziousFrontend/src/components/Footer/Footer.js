import React from "react";
import "./Footer.css";
import footerEndImg from "../../images/footer-end-img.webp";
import logo from "../../images/logo.png";
import phone from "../../images/phone.png";
import mail from "../../images/mail.png";
import location from "../../images/location.png";
import googleLogin from "../../images/google-login.svg";
import appleLogin from "../../images/fb-login.svg";
import timing from "../../images/alarm.png";
import facebook from "../../images/facebookLogin.webp";
import instagram from "../../images/instagramLogin.webp";

export default function Footer() {
  return (
    <div className="footer-main">
      <div className="footer-inner">
        <div className="footer">
          <div className="footer-left">
            <div className="footer-left-inner">
              <a href="/" className="footer-logo">
                <span className="footer-logo-inner">
                  <img className="footer-logo-img" src={logo} alt="no img" />
                </span>
              </a>
              <div className="footer-dash-inner"></div>
              <div className="footer-left-content">
                <span className="footer-left-heading">Cheezious</span>
                <div className="phone">
                  <img src={phone} className="phone-icon" alt="no img" />
                  <a href="tel:051111446699" className="phone-number">
                    <span className="phone-heading">Phone:</span>
                    051111446699
                  </a>
                </div>
                <div className="email">
                  <img src={mail} className="mail-icon" alt="no img" />
                  <a
                    href="mailto:support@cheezious.com"
                    className="email-address"
                  >
                    <span className="email-heading">Email:</span>
                    support@cheezious.com
                  </a>
                </div>
                <div className="address">
                  <img src={location} className="address-icon" alt="no img" />
                  <span className="location-address">
                    <span className="address-heading">Address:</span>
                    Cheezious - Peshawar Morr, 987/740 plaza, besides Allied
                    Bank,, Hajji Camp Road, Peshawar Morr, Islamabad
                  </span>
                </div>
                <div className="login-icons">
                  <a
                    href="https://play.google.com/store/apps/details?id=com.blink.cheezious&hl=en&gl=US&pli=1"
                    className="google-login"
                  >
                    <span className="google-login-inner">
                      <img
                        src={googleLogin}
                        alt="no img"
                        className="google-login-img"
                      />
                    </span>
                  </a>
                  <a
                    href="https://apps.apple.com/pk/app/cheezious/id1535315212"
                    className="apple-login"
                  >
                    <span className="apple-login-inner">
                      <img
                        src={appleLogin}
                        alt="no img"
                        className="apple-login-img"
                      />
                    </span>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div className="footer-right">
            <div className="footer-right-inner">
              <div className="timings">
                <img src={timing} alt="" className="timings-img" />
                <span className="timing-heading">Our Timings</span>
              </div>
              <div className="weekdays">
                <span className="weekdays-name">Monday - Thursday</span>
                <div className="weekdays-dash"></div>
                <span className="weekdays-timing">11:00 AM - 03:00 AM</span>
              </div>
              <div className="friday">
                <span className="friday-name">Friday</span>
                <div className="friday-dash"></div>
                <span className="friday-timing">2:00 PM - 03:00 AM</span>
              </div>
              <div className="weekend">
                <span className="weekend-name">Saturday - Sunday</span>
                <div className="weekend-dash"></div>
                <span className="weekend-timing">11:00 AM - 03:00 AM</span>
              </div>
              <div className="logins">
                <span className="logins-inner">Follow Us:</span>
                <div className="logins-imgs">
                  <a
                    href="https://m.facebook.com/Cheezious/"
                    className="fb-logins"
                  >
                    <img src={facebook} alt="no img" />
                  </a>
                  <a
                    href="https://www.instagram.com/cheeziouspakistan/?igshid=YmMyMTA2M2Y%3D"
                    className="insta-logins"
                  >
                    <img src={instagram} alt="no img" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <hr className="footer-dash" />
        <div className="footer-below">
          <div className="copyright">
            <span className="copyright-inner">
              © 2022 Powered by
              <a
                href="https://www.blinkco.io/"
                target="_blank"
                rel="noreferrer"
                className="copyright-link"
              >
                Blink Co.
              </a>
            </span>
          </div>
        </div>
        <div className="footer-end">
          <span className="footer-end-inner">
            <img className="footer-end-img" src={footerEndImg} alt="no img" />
          </span>
        </div>
      </div>
    </div>
  );
}
