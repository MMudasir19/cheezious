import React, { useState, useEffect } from "react";
import "./Categories.css";
import { Link } from "react-scroll";

export default function Categories(props) {
  const [isVisible, setIsVisible] = useState(false);
  useEffect(() => {
    window.addEventListener("scroll", listenToScroll);
    return () => window.removeEventListener("scroll", listenToScroll);
    // eslint-disable-next-line
  }, []);
  const listenToScroll = () => {
    if (window.scrollY > 550) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  };

  const slideleft = () => {
    var slider = document.getElementById("slideleft");
    slider.scrollLeft = slider.scrollLeft - 1000;
  };
  const slideright = () => {
    var slider = document.getElementById("slideleft");
    slider.scrollLeft = slider.scrollLeft + 1000;
  };

  const [isActive, setIsActive] = useState(false);

  const handleClick = () => {
    setIsActive((current) => !current);
  };
  return (
    <>
      {isVisible && (
        <div className="categories-container">
          <div className="categories-inner">
            <div className="prev-btn" onClick={slideleft}>
              {" "}
              &#10094;
            </div>
            <div id="slideleft" className="categories-content">
              <div className="categories-name">
                {props.data.map((item, i) => {
                  return (
                    <button className="categories-btn" key={i}>
                      <Link
                        to={item.category}
                        className={isActive ? "active" : "category-name"}
                        onScroll={handleClick}
                        spy={true}
                        smooth={true}
                        offset={-205}
                      >
                        {item.category}
                      </Link>
                    </button>
                  );
                })}
                <span className="category-style"></span>
              </div>
            </div>
            <div className="next-btn" onClick={slideright}>
              &#10095;
            </div>
          </div>
        </div>
      )}
    </>
  );
}
