import React, { useState } from "react";
import "./CategoryBlock.css";
import { Link } from "react-scroll";

export default function CategoryBlock(props) {
  const [isActive, setIsActive] = useState(false);

  const handleClick = () => {
    setIsActive((current) => !current);
  };
  return (
    <>
      <div className="category-block">
        {props.data.map((item, i) => {
          return (
            <button className="categories-btn" key={i}>
              <Link
                to={item.category}
                className={isActive ? "active" : "category-name"}
                onScroll={handleClick}
                spy={true}
                smooth={true}
                offset={-152.5}
              >
                {item.category}
              </Link>
            </button>
          );
        })}
        <span className="category-style"></span>
      </div>
      {/* categories at 900px */}
      <div className="categories-container1">
        <div className="categories-inner1">
          <div id="slideleft" className="categories-content1">
            <div className="categories-name">
              {props.data.map((item, i) => {
                return (
                  <button className="categories-btn" key={i}>
                    <Link
                      to={item.category}
                      className={isActive ? "active" : "category-name"}
                      onScroll={handleClick}
                      spy={true}
                      smooth={true}
                      offset={-100}
                    >
                      {item.category}
                    </Link>
                  </button>
                );
              })}
              <span className="category-style"></span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
