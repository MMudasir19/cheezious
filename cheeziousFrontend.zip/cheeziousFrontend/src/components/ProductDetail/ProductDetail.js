/* eslint-disable jsx-a11y/anchor-has-content */
import React, { useState, useEffect } from "react";
import "./ProductDetail.css";
import rightArrow from "../../images/rightArrow.png";
import heart from "../../images/heart.png";
import { useParams, useNavigate } from "react-router-dom";
import RelatedProduct from "./RelatedProduct/RelatedProduct";

export default function ProductDetail(props) {
  const navigate = useNavigate();
  const params = useParams(); // eslint-disable-next-line
  const [idData, setIdData] = useState([]);
  const [idDataCategory, setIdDataCategory] = useState("");
  const [idDataRelated, setIdDataRelated] = useState([]);
  useEffect(() => {
    window.scrollTo(0, 0);
    getIdData(params.id);
    // eslint-disable-next-line
  }, [params.id]);
  const getIdData = async (paramsId) => {
    try {
      const response = await fetch(
        `http://192.168.100.63:9000/user_side/get_product_detail/${paramsId}`
      );
      if (!response.ok) {
        throw new Error(
          `This is an HTTP error: The status is ${response.status}`
        );
      }
      let actualData = await response.json();
      setIdData(actualData.data.product);
      setIdDataCategory(actualData.data.category_name);
      setIdDataRelated(actualData.data.related_products);
      props.setError(null);
    } catch (err) {
      props.setError(err.message);
      setIdData(null);
    } finally {
      props.setLoading(false);
    }
  };

  const handleClick = (item) => {
    window.scrollTo(0, 0);

    navigate(`/product/${item.id}/${item.title}`);
    getIdData(item.id);
  };

  return (
    <>
      <div className="product-detail">
        <nav className="product-detail-nav">
          <ol className="product-detail-nav-inner">
            <li>
              <div
                onClick={() => {
                  navigate("/");
                }}
                className="product-detail-nav-heading"
              >
                Home
              </div>
            </li>
            <li className="product-detail-nav-divider">
              <img
                className="product-nav-divider-img"
                src={rightArrow}
                alt="no img"
              />
            </li>
            <li>
              <span className="product-detail-title">{idData.title}</span>
            </li>
          </ol>
        </nav>
        <div className="product-detail-content">
          <div className="product-detail-content-inner">
            <div className="pdci-text">
              <div className="pdci-img">
                <div className="pdci-image">
                  <div className="pdci-image-inner">
                    <div className="pdci-image-upper">
                      <div className="pdi">
                        <img
                          className="pdi-image"
                          src={idData.image}
                          alt="no img"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="pdci-content">
                <a href="/" className="pdci-anchor"></a>
                <div>
                  <h2 className="pdci-heading">{idData.title}</h2>
                </div>
                <div className="pdci-description">
                  <p className="pdci-decription-inner">{idData.discription}</p>
                </div>
                <div className="pdci-fav">
                  <img className="pdci-fav-img" src={heart} alt="no img" />
                  <span className="pdci-fav-span">Add to Favourite</span>
                </div>
                <div>
                  <div className="pdci-button">
                    <span>{idData.price}</span>
                  </div>
                  <div className="pdci-button-span">
                    <div className="pdci-button-inner">
                      <button className="pdci-button-btn">Add To Cart</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* product-detail-related */}
      <RelatedProduct
        idDataCategory={idDataCategory}
        handleClick={handleClick}
        idDataRelated={idDataRelated}
      />
    </>
  );
}
