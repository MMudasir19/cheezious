import React from "react";
import heart from "../../../images/heart.png";

export default function RelatedProduct(props) {
  return (
    <>
      <div className="pdc">
        <span className="pdc-heading">
          <h3 className="pdc-title">More in {props.idDataCategory}</h3>
        </span>
      </div>
      <div className="pdc-related">
        <div className="slider-container">
          <div className="prev-arrow">
            <div className="prev-inner">
              <span className="prev">&#10094;</span>
            </div>
          </div>
          <div className="next-arrow">
            <div className="next-inner">
              <span className="next">&#10095;</span>
            </div>
          </div>
          <div className="pdc-related-inner">
            <div className="pdc-related-main">
              <div className="pdcr-main-inner">
                {props.idDataRelated.map((item, i) => {
                  return (
                    <div
                      onClick={() => {
                        props.handleClick(item);
                      }}
                      className="card"
                      key={i}
                    >
                      <div className="card-inner">
                        <div className="card-img">
                          <div className="card-image">
                            <img className="item-img" src={item.image} alt="" />
                          </div>
                          <img className="heart" src={heart} alt="no img" />
                        </div>
                        <div className="card-text">
                          <span className="item-name">{item.title}</span>
                          <p className="item-description">{item.discription}</p>
                          <div className="price-tag"></div>
                          <div className="price">
                            <span>{item.price}</span>
                          </div>
                          <button className="item-btn">
                            Add to Cart
                            <span className="item-space"></span>
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
