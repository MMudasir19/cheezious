import React from "react";
import { useNavigate } from "react-router-dom";

export default function SearchCard(props) {
  const navigate = useNavigate();
  let product = props.product;
  return (
    <div key={product.id} className="search-result">
      <div
        onClick={() => {
          navigate(`/product/${props.product.id}/${props.product.title}`);
        }}
        className="search-item"
      >
        <div className="search-img">
          <img
            className="search-image"
            alt={product.title}
            src={product.image}
          />
        </div>
        <div className="search-text">
          <p className="search-text-heading">{product.title}</p>
          <p className="search-text-category">{product.category_name}</p>
        </div>
      </div>
    </div>
  );
}
