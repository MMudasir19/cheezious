import React from "react";

export default function Search(props) {
  return (
    <div className="popup-box">
      <div className="box1">
        <div className="box2">
          <div className="search-heading">Search</div>
          <div className="close-icon1" onClick={props.togglePopupSearch}>
            x
          </div>
        </div>
        <div>
          <div className="search-input">
            <div className="search-input-inner">
              <input
                className="popup-select"
                type="search"
                placeholder="Search"
                onChange={props.handleChange}
              />
            </div>
          </div>
          {props.loading ? (
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                margin: "10rem",
              }}
            >
              {props.spinner}
            </div>
          ) : (
            <>
              <div onClick={props.togglePopupSearch}>
                {props.searchList() ? (
                  props.searchList()
                ) : (
                  <div className="no-result">No result found</div>
                )}
              </div>
            </>
          )}
          {props.error && (
            <div>{`There is a problem fetching the post data - ${props.error}`}</div>
          )}
        </div>
        {props.searchList() && (
          <a href="/" className="search-anchor">
            View all results
          </a>
        )}
      </div>
    </div>
  );
}
