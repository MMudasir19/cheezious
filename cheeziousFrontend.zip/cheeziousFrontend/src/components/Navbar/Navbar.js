import React, { useState, useEffect } from "react";
import "./Navbar.css";
import location from "../../images/location.png";
import logo from "../../images/logo.png";
import search from "../../images/search.png";
import user from "../../images/user.png";
import deliveryArrow from "../../images/deliveryArrow.png";
import SearchCard from "./SearchCard/SearchCard";
import Search from "./Search/Search";
import Location from "./Location/Location";
import MobileNumber from "./MobileNumber/MobileNumber";
import Cart from "./Sidebar/Cart";

export default function Navbar(props) {
  const [selectedCity, setSelectedCity] = useState("");
  const [selectedArea, setSelectedArea] = useState("");
  const [getArea, getUserArea] = useState("");
  const [userCity, getUserCity] = useState("");
  const [searchField, setSearchField] = useState("");
  const [searchShow, setSearchShow] = useState(false);
  const [isOpenLocation, setIsOpenLocation] = useState(false);
  const [isOpenSearch, setIsOpenSearch] = useState(false);
  const [isOpenMobileNumber, setIsOpenMobileNumber] = useState(false);
  const filteredProduct = props.data.map((item) => {
    return item[item.category].filter((item) => {
      return item.title.toLowerCase().includes(searchField.toLowerCase());
    });
  });

  const filtered = filteredProduct.map((item) => {
    return item.map((product) => {
      return (
        <>
          <SearchCard product={product} />
        </>
      );
    });
  });

  const handleChange = (e) => {
    setSearchField(e.target.value);
    if (e.target.value === "") {
      setSearchShow(false);
    } else {
      setSearchShow(true);
    }
  };

  const searchList = () => {
    if (searchShow) {
      return <div>{filtered}</div>;
    }
  };

  const togglePopupLocation = () => {
    setIsOpenLocation(!isOpenLocation);
  };
  const togglePopupSearch = () => {
    setIsOpenSearch(!isOpenSearch);
    setSearchShow(false);
  };
  const togglePopupMobileNumber = () => {
    setIsOpenMobileNumber(!isOpenMobileNumber);
  };

  const saveLocation = () => {
    sessionStorage.setItem("userArea", selectedArea);
    sessionStorage.setItem("userCity", userCity);
    getUserArea(selectedArea);
    getUserCity(selectedCity);
    togglePopupLocation();
  };

  useEffect(() => {
    if (sessionStorage.getItem("userArea") === null) {
      setIsOpenLocation(true);
    }
  }, []);

  return (
    <>
      <div className="navbar">
        <div className="navbar-main">
          <div className="navbar-inner">
            <div className="location">
              <img
                onClick={togglePopupLocation}
                className="location-img"
                src={location}
                alt="no img"
              />
              <div onClick={togglePopupLocation} className="location-text">
                <div className="locationText-1">
                  <span className="delivery">Deliver to</span>
                  <img
                    className="delivery-icon"
                    src={deliveryArrow}
                    alt="no img"
                  />
                </div>
                <span className="location-name">
                  {sessionStorage.getItem("userArea")
                    ? sessionStorage.getItem("userArea")
                    : "26 Number Bus Stop -RWP, Islamabad"}
                </span>
              </div>
            </div>
            <a href="/" className="logo">
              <span className="logo-img">
                <img className="cheezious-logo" src={logo} alt="no img" />
              </span>
            </a>
            <div className="options">
              <div className="search">
                <img
                  onClick={togglePopupSearch}
                  className="search-icon"
                  src={search}
                  alt="no img"
                />
              </div>
              <hr className="separate-1" />
              <div onClick={togglePopupMobileNumber} href="/" className="user">
                <img className="user-icon" src={user} alt="no img" />
              </div>
              <hr className="separate-2" />
              <div className="cart">
                {/* sidebar */}
                <Cart
                  cartItems={props.cartItems}
                  onAdd={props.onAdd}
                  onRemove={props.onRemove}
                  countCartItems={props.countCartItems}
                  cartItem={props.cartItem}
                  num={props.num}
                  togglePopupClearCart={props.togglePopupClearCart}
                  isOpenClearCart={props.isOpenClearCart}
                  setNum={props.setNum}
                  setIsOpenClearCart={props.setIsOpenClearCart}
                />
                {/*  */}
              </div>
            </div>
          </div>
        </div>
        {/* pop-up-form location */}
        {isOpenLocation && (
          <>
            <Location
              selectedCity={selectedCity}
              setSelectedCity={setSelectedCity}
              getUserCity={getUserCity}
              userCity={userCity}
              setSelectedArea={setSelectedArea}
              selectedArea={selectedArea}
              searchField={searchField}
              saveLocation={saveLocation}
              getUserArea={getUserArea}
              getArea={getArea}
              togglePopupLocation={togglePopupLocation}
            />
          </>
        )}
        {/* search by category */}
        {isOpenSearch && (
          <>
            <Search
              togglePopupSearch={togglePopupSearch}
              loading={props.loading}
              searchList={searchList}
              handleChange={handleChange}
            />
          </>
        )}
        {/* user login */}
        {isOpenMobileNumber && (
          <>
            <MobileNumber togglePopupMobileNumber={togglePopupMobileNumber} />
          </>
        )}
      </div>
    </>
  );
}
