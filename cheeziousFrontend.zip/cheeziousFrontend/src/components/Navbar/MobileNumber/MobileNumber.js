import React, { useState } from "react";
import "react-phone-number-input/style.css";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

export default function MobileNumber(props) {
  const [value, setValue] = useState();
  return (
    <div className="popup-box">
      <div className="box1-1">
        <div className="box2">
          <div className="search-heading">Enter your mobile number</div>
          <div className="close-icon1" onClick={props.togglePopupMobileNumber}>
            x
          </div>
        </div>
        <p>Please confirm your country code and enter your mobile number.</p>
        <PhoneInput
          name="phoneNumber"
          type="text"
          country={"pk"}
          enableAreaCodes={true}
          inputProps={{
            name: "phone",
            country: "pk",
            required: true,
            autoFocus: true,
          }}
          value={value}
          onChange={setValue}
          containerStyle={{
            border: "1px solid #FFA500",
            borderRadius: "5px",
            height: "8vh",
            marginBottom: "10px",
          }}
          inputStyle={{
            width: "100%",
            height: "7.7vh",
            border: "1px solid #FFA500",
          }}
          required
        />
        <button className="popup-type-btn2">Continue</button>
        <a href="/" className="continue-guest">
          Continue as a guest
        </a>
      </div>
    </div>
  );
}
