import React, { useState, useEffect } from "react";
import logo from "../../../images/logo.png";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
// import { makeStyles } from "@mui/material/styles";
import { makeStyles } from "@mui/styles";
const useStyles = makeStyles((theme) => ({
  root: {
    "& .MuiInputLabel-outlined:not(.MuiInputLabel-shrink)": {
      transform: "translate(34px, 20px) scale(1);",
    },
    "&.Mui-focused .MuiInputLabel-outlined": {
      color: "#FFA500",
    },
  },
  inputRoot: {
    "& .MuiOutlinedInput-notchedOutline": {
      borderColor: "gray",
    },
    "&:hover .MuiOutlinedInput-notchedOutline": {
      borderColor: "black",
    },
    "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderColor: "#FFA500",
    },
  },
}));

export default function Location(props) {
  const classes = useStyles();
  const [cities, setCities] = useState([]);
  const [areas, setAreas] = useState([]);
  const [isValid, setValid] = useState(false);

  useEffect(() => {
    getCity();
  }, []);

  const url = "http://192.168.100.63:9000/user_side/list_branches";
  const getCity = async () => {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(
          `This is an HTTP error: The status is ${response.status}`
        );
      }
      let actualData = await response.json();
      setCities(await actualData.data);
    } catch (err) {
      setCities(null);
    }
  };

  const handleChangeCity = (value) => {
    props.setSelectedCity(value.id);
    props.getUserCity(value.city);
  };

  const URLArea = `http://192.168.100.63:9000/user_side/area/?city_id=${props.selectedCity}`;
  useEffect(() => {
    validate();
    getArea();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.selectedCity, props.selectedArea]);
  const getArea = async () => {
    try {
      const response = await fetch(URLArea);
      if (!response.ok) {
        throw new Error(
          `This is an HTTP error: The status is ${response.status}`
        );
      }
      let actualData = await response.json();
      setAreas(actualData.data);
    } catch (err) {
      setAreas(null);
    }
  };

  const validate = () => {
    if (props.selectedArea && props.selectedCity) {
      setValid(true);
    } else {
      setValid(false);
    }
  };

  const handleChangeArea = (value) => {
    props.setSelectedArea(value.area);
    props.getUserArea(value.area);
  };

  return (
    <>
      <div className="popup-box">
        <div className="box">
          <div className="close-icon-outer">
            {props.selectedArea ? (
              <div className="close-icon" onClick={props.togglePopupLocation}>
                x
              </div>
            ) : (
              ""
            )}
          </div>
          <div className="logo-popup">
            <span className="logo-img">
              <img className="cheezious-logo" src={logo} alt="no img" />
            </span>
          </div>
          <p className="popup-type">Select your order type</p>
          <div className="popup-btn">
            <button className="popup-type-btn">DELIVERY</button>
          </div>
          <p className="popup-type">Please select your location</p>
          <p className="popup-type1">Currently Selected</p>
          <div className="popup-location">
            <p className="popup-type2">
              {sessionStorage.getItem("userArea")
                ? sessionStorage.getItem("userArea")
                : " Your Location"}
            </p>
          </div>
          <Autocomplete
            classes={classes}
            onChange={(event, value) => handleChangeCity(value)}
            id="cities"
            getOptionLabel={(cities) => `${cities.city}`}
            options={cities}
            sx={{ width: 560, marginBottom: "15px" }}
            renderInput={(params) => (
              <TextField {...params} label="Select City" variant="outlined" />
            )}
            isOptionEqualToValue={(option, value) =>
              option.value === value.value
            }
          />
          <Autocomplete
            classes={classes}
            onChange={(event, value) => handleChangeArea(value)}
            id="cities"
            getOptionLabel={(areas) => `${areas.area}`}
            options={areas}
            sx={{ width: 560, marginBottom: "15px" }}
            renderInput={(params) => (
              <TextField {...params} label="Select Area" variant="outlined" />
            )}
            isOptionEqualToValue={(option, value) =>
              option.value === value.value
            }
          />
          <button
            onClick={props.saveLocation}
            disabled={!isValid}
            className={
              !isValid ? "popup-type-btn1-disabled" : "popup-type-btn1"
            }
          >
            Select
          </button>
        </div>
      </div>
    </>
  );
}
