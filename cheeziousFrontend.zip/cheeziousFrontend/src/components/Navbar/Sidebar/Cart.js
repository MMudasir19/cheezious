import React, { useState } from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Button from "@mui/material/Button";
import cart from "../../../images/cart.png";
import cartButton from "../../../images/cartButton.png";
import Divider from "@mui/material/Divider";
import { Fragment } from "react";
import emptyCart from "../../../images/cart-empty.svg";
import deleteImg from "../../../images/bin.png";
export default function TemporaryDrawer(props) {
  const [open, setOpen] = useState(false);
  const toggleSlider = () => {
    setOpen(!open);
  };
  const clearCart = () => {
    props.setIsOpenClearCart(false);
    sessionStorage.removeItem("cartItems");
    props.cartItems.length = 0;
  };
  const totalPrice = props.cartItems.reduce((a, c) => a + c.qty * c.price, 0);
  return (
    <div>
      <Fragment>
        <Button onClick={toggleSlider}>
          {props.countCartItems ? (
            <div className="cart-icon">{props.countCartItems}</div>
          ) : (
            <div className="cart-icon">0</div>
          )}
          <img className="cart-img" src={cart} alt="no img" />
          <img className="cartButton" src={cartButton} alt="no img" />
        </Button>
        <Drawer
          open={open}
          anchor="right"
          onClose={toggleSlider}
          PaperProps={{
            elevation: 0,
            style: { borderTopLeftRadius: 15, borderBottomLeftRadius: 15 },
          }}
        >
          {props.cartItems.length === 0 ? (
            // empty-cart
            <Box className="cart-style" component="div">
              <Divider />
              <div className="cart-heading">Your Cart</div>
              <Divider />
              <div className="empty-cart">
                <div>
                  <div className="empty-cart-content">
                    <img
                      src={emptyCart}
                      alt="no cart"
                      className="emptyCart-img"
                    />
                  </div>
                  <div className="empty-cart-content">Your cart is empty</div>
                  <div className="empty-cart-content">
                    Add an item and start making your order
                  </div>
                </div>
              </div>
            </Box>
          ) : (
            <Box className="cart-style" component="div">
              <div className="cart-head">
                <div className="cart-heading">Your Cart</div>
                <div
                  className="clear-cart"
                  onClick={props.togglePopupClearCart}
                >
                  Clear Cart
                </div>
                {/* clear-cart-popup */}
                {props.isOpenClearCart && (
                  <div className="clear-cart-popup">
                    <span>Are you sure?</span>
                    <div className="clear-cart-surety">
                      <button
                        className="clear-cart-cancel"
                        onClick={props.togglePopupClearCart}
                      >
                        Cancel
                      </button>
                      <button
                        className="clear-cart-confirm"
                        onClick={clearCart}
                      >
                        Clear Cart
                      </button>
                    </div>
                  </div>
                )}
              </div>
              {/* cart-item */}
              <div className="filled-cart">
                {props.cartItems.length > 0
                  ? props.cartItems.map((item, i) => {
                      return (
                        <div key={i} className="filled-cart-item">
                          <div className="filled-cart-item-number">
                            {item.qty}
                          </div>
                          <div className="filled-cart-item-img">
                            <span className="filled-cart-item-image">
                              <img
                                src={item.image}
                                alt={item.title}
                                className="cart-item-image-img"
                              />
                            </span>
                          </div>
                          <div className="filled-cart-item-detail">
                            <div className="filled-cart-item-detail-heading">
                              {item.title}
                            </div>
                            <div className="filled-cart-item-detail-discription">
                              {item.discription}
                            </div>
                            <span className="filled-cart-item-detail-variation">
                              Variation
                            </span>

                            <span className="filled-cart-item-detail-variation-type">
                              {/* + {variation[0]} */}
                            </span>

                            <span className="filled-cart-item-detail-variation">
                              Extra Topping
                            </span>

                            <span className="filled-cart-item-detail-variation-type"></span>
                            <div className="cart-item-operations">
                              <div className="cart-item-operations-btns">
                                <span
                                  className="cart-operations-buttons"
                                  onClick={() => props.onRemove(item)}
                                >
                                  -
                                </span>
                                <span
                                  className="cart-operations-buttons"
                                  onClick={() => props.onAdd(item)}
                                >
                                  +
                                </span>
                                <span className="cart-item-added-price">
                                  {item.qty} x ${item.price}
                                </span>
                              </div>
                              <img
                                src={deleteImg}
                                alt="no img"
                                className="cart-item-delete-btn"
                              />
                            </div>
                          </div>
                        </div>
                      );
                    })
                  : ""}
              </div>

              {/* cart-footer */}
              <div className="cart-footer-outer">
                <div className="cart-total-footer">
                  <div className="cart-total-delivery">
                    You've got FREE delivery!
                  </div>
                  <div className="cart-total-amount">
                    <span>Subtotal</span>
                    <span className="cart-item-added-price">
                      Rs. {totalPrice}
                    </span>
                  </div>
                  <div className="cart-total-amount">
                    <span>Delivery Charges</span>
                    <span className="cart-item-added-price">Rs. 0</span>
                  </div>
                  <div className="cart-total-grand">
                    <span>Grand Total</span>
                    <span>Rs. {totalPrice}</span>
                  </div>
                  <button className="checkout">Checkout</button>
                </div>
              </div>
            </Box>
          )}
        </Drawer>
      </Fragment>
    </div>
  );
}
