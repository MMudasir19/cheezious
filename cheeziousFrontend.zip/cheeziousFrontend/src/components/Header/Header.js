import React from "react";
import "./Header.css";

export default function Header() {
  return (
    <div className="header">
      Sorry, we are closed. Will re-open at 11:00 AM.
    </div>
  );
}
