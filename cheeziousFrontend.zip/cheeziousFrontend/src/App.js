import Header from "../src/components/Header/Header";
import Navbar from "../src/components/Navbar/Navbar";
import Slider from "../src/components/Slider/Slider";
import Categories from "../src/components/Categories/Categories";
import CategoryBlock from "../src/components/CategoryBlock/CategoryBlock";
import CategoryItems from "../src/components/CategoryItems/CategoryItems";
import spinner from "./images/spinner.gif";
import "./App.css";
import AboutUs from "./components/AboutUs/AboutUs";
import Footer from "./components/Footer/Footer";
import React, {
  useState,
  useEffect,
  useTransition,
  useDeferredValue,
} from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ProductDetail from "./components/ProductDetail/ProductDetail";

function App() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const url = "http://192.168.100.63:9000/user_side/list_product/";
  const getData = async () => {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(
          `This is an HTTP error: The status is ${response.status}`
        );
      }
      let actualData = await response.json();
      setData(actualData.data);
      setError(null);
    } catch (err) {
      setError(err.message);
      setData(null);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    getData();
  }, []);

  const [isOpenClearCart, setIsOpenClearCart] = useState(false);
  const togglePopupClearCart = () => {
    setIsOpenClearCart(!isOpenClearCart);
  };

  const [cartItems, setCartItems] = useState([]);
  const onAdd = (product) => {
    const exist = cartItems.find((x) => x.id === product.id);
    if (exist) {
      const newCartItems = cartItems.map((x) =>
        x.id === product.id ? { ...exist, qty: exist.qty + 1 } : x
      );
      setCartItems(newCartItems);
      sessionStorage.setItem("cartItems", JSON.stringify(newCartItems));
    } else {
      const newCartItems = [...cartItems, { ...product, qty: 1 }];
      setCartItems(newCartItems);
      sessionStorage.setItem("cartItems", JSON.stringify(newCartItems));
    }
  };
  const onRemove = (product) => {
    const exist = cartItems.find((x) => x.id === product.id);
    if (exist.qty === 1) {
      const newCartItems = cartItems.filter((x) => x.id !== product.id);
      setCartItems(newCartItems);
      sessionStorage.setItem("cartItems", JSON.stringify(newCartItems));
    } else {
      const newCartItems = cartItems.map((x) =>
        x.id === product.id ? { ...exist, qty: exist.qty - 1 } : x
      );
      setCartItems(newCartItems);
      sessionStorage.setItem("cartItems", JSON.stringify(newCartItems));
    }
  };

  const [isPending, startTransition] = useTransition();
  useEffect(() => {
    startTransition(() => {
      setCartItems(
        sessionStorage.getItem("cartItems")
          ? JSON.parse(sessionStorage.getItem("cartItems"))
          : []
      );
    });
  }, []);
  const cartItemsCount = useDeferredValue(cartItems.length);
  return (
    <BrowserRouter>
      <div className="App">
        {isPending ? (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              margin: "10rem",
            }}
          >
            <div>
              <img
                style={{ width: "5rem", height: "6rem" }}
                src={spinner}
                alt="Loading..."
              />
              <div>Loading...</div>
            </div>
          </div>
        ) : (
          <>
            <Header />

            <Navbar
              cartItems={cartItems}
              onAdd={onAdd}
              onRemove={onRemove}
              countCartItems={cartItemsCount}
              setError={setError}
              setLoading={setLoading}
              data={data}
              loading={loading}
              spinner={spinner}
              togglePopupClearCart={togglePopupClearCart}
              isOpenClearCart={isOpenClearCart}
              setIsOpenClearCart={setIsOpenClearCart}
            />

            <Routes>
              <Route
                index
                path="/"
                element={
                  <>
                    <Slider />
                    <Categories data={data} />
                    <CategoryBlock data={data} />
                    <CategoryItems
                      data={data}
                      onAdd={onAdd}
                      onRemove={onRemove}
                      cartItems={cartItems}
                    />
                    <AboutUs />
                  </>
                }
              />
              <Route
                exact
                path="/product/:id/:name"
                element={
                  <ProductDetail
                    setError={setError}
                    setLoading={setLoading}
                    data={data}
                    spinner={spinner}
                  />
                }
              />
            </Routes>
            <Footer />
          </>
        )}
        {error && (
          <div>{`There is a problem fetching the post data - ${error}`}</div>
        )}
      </div>
    </BrowserRouter>
  );
}

export default App;
